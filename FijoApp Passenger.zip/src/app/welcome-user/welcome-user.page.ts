import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-user',
  templateUrl: './welcome-user.page.html',
  styleUrls: ['./welcome-user.page.scss'],
})
export class WelcomeUserPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
