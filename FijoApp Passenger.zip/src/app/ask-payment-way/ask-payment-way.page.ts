import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-ask-payment-way',
  templateUrl: './ask-payment-way.page.html',
  styleUrls: ['./ask-payment-way.page.scss'],
})
export class AskPaymentWayPage implements OnInit {

  constructor(public modal: ModalController) { }

  ngOnInit() {
  }
  IsSaving = false;
  onSelect() {
    this.IsSaving = true;
    setTimeout(() => {
      this.modal.dismiss()
    }, 1500);
  }

}
