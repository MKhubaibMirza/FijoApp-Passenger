export const environment = {
  production: true,
  baseUrl: 'http://167.172.212.80:3000/'
};
